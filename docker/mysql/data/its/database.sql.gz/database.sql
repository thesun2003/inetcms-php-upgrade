-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 26, 2018 at 11:33 AM
-- Server version: 5.6.39-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aqq999_itsnsk2`
--

-- --------------------------------------------------------

--
-- Table structure for table `itsnsk_admins`
--

CREATE TABLE `itsnsk_admins` (
  `id` smallint(6) NOT NULL,
  `login` varchar(255) NOT NULL,
  `passw` varchar(255) NOT NULL,
  `privileges` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `itsnsk_admins`
--

INSERT INTO `itsnsk_admins` (`id`, `login`, `passw`, `privileges`) VALUES
(1, 'thesun2003', '39babc59304df111cf56ad24e418e8de', 1),
(2, 'admin', '858ba104705524c063bf51d62e468064', 1);

-- --------------------------------------------------------

--
-- Table structure for table `itsnsk_clients`
--

CREATE TABLE `itsnsk_clients` (
  `id` smallint(6) NOT NULL,
  `login` varchar(255) NOT NULL,
  `passw` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `itsnsk_clients`
--

INSERT INTO `itsnsk_clients` (`id`, `login`, `passw`, `title`) VALUES
(1, 'thesun2003@gmail.com', '39babc59304df111cf56ad24e418e8de', 'Тест'),
(2, 'info@inet-s.ru', '6b98eda9e022c7573e21ff3765a85036', 'Инет Сервис'),
(3, 'mila555@mail.ru', 'fc402e5c6d73ff25c750fe61574a2257', 'Sibir');

-- --------------------------------------------------------

--
-- Table structure for table `itsnsk_gallery`
--

CREATE TABLE `itsnsk_gallery` (
  `id` smallint(6) NOT NULL,
  `col_num` smallint(6) NOT NULL DEFAULT '4',
  `limit` smallint(6) NOT NULL DEFAULT '-1',
  `width` smallint(6) NOT NULL DEFAULT '200',
  `parent_id` smallint(6) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Table structure for table `itsnsk_images`
--

CREATE TABLE `itsnsk_images` (
  `id` smallint(6) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `gallery_id` smallint(6) NOT NULL DEFAULT '-1',
  `descr` varchar(500) NOT NULL,
  `position` smallint(6) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Table structure for table `itsnsk_installed_modules`
--

CREATE TABLE `itsnsk_installed_modules` (
  `id` smallint(6) NOT NULL,
  `name` varchar(255) NOT NULL,
  `module_name` varchar(255) NOT NULL,
  `module_id` varchar(255) NOT NULL,
  `menu_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `itsnsk_installed_modules`
--

INSERT INTO `itsnsk_installed_modules` (`id`, `name`, `module_name`, `module_id`, `menu_id`) VALUES
(1, 'Клиенты и сообщения', 'Clients', 'clients_id', 0);

-- --------------------------------------------------------

--
-- Table structure for table `itsnsk_menu`
--

CREATE TABLE `itsnsk_menu` (
  `id` smallint(6) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` enum('menu','page') NOT NULL DEFAULT 'menu',
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `descr` varchar(255) NOT NULL,
  `keyw` varchar(255) NOT NULL,
  `parent_id` smallint(6) NOT NULL DEFAULT '0',
  `position` smallint(6) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `itsnsk_menu`
--

INSERT INTO `itsnsk_menu` (`id`, `name`, `type`, `visible`, `title`, `descr`, `keyw`, `parent_id`, `position`) VALUES
(1, 'Главная', 'menu', 0, '', '', '', 0, 1),
(2, 'Услуги', 'menu', 0, '', '', '', 0, 2),
(3, 'Преимущества', 'menu', 0, '', '', '', 0, 3),
(4, 'Вход для клиентов', 'menu', 0, '', '', '', 0, 4),
(5, 'Задать вопрос', 'menu', 0, '', '', '', 0, 5),
(6, 'Примерный расчет стоимости обслуживания', 'menu', 0, '', '', '', 0, 6),
(7, 'Системное администрирование', 'menu', 0, '', '', '', 2, 7),
(8, 'Регистрация доменов', 'menu', 0, '', '', '', 2, 8),
(9, 'Контакты', 'menu', 0, '', '', '', 0, 9),
(12, 'Ваше сообщение послано', 'page', 0, '', '', '', 5, 12);

-- --------------------------------------------------------

--
-- Table structure for table `itsnsk_messages`
--

CREATE TABLE `itsnsk_messages` (
  `id` smallint(6) NOT NULL,
  `type` enum('ask','answer') NOT NULL DEFAULT 'ask',
  `client_id` smallint(6) NOT NULL,
  `message` longtext NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `itsnsk_messages`
--

INSERT INTO `itsnsk_messages` (`id`, `type`, `client_id`, `message`, `date_added`) VALUES
(1, 'ask', 1, '<p>первое тестовое сообщение</p>', '2011-09-15 13:41:58'),
(2, 'ask', 1, '<p>и еще одно в догонку!</p>', '2011-09-15 13:42:37'),
(3, 'ask', 1, '<p>а почему не удаляется?</p>', '2011-09-15 13:43:02'),
(4, 'ask', 1, '<p>очень странно..</p>', '2011-09-15 13:43:20'),
(5, 'answer', 1, '<p>точно не удаляется?</p>', '2011-09-15 13:44:24'),
(6, 'answer', 1, '<p>а сейчас как?</p>', '2011-09-15 13:44:59'),
(7, 'answer', 1, '<p>вот сейчас точно должно!</p>', '2011-09-15 13:45:27'),
(8, 'ask', 2, '<p>Люда, привет!</p>\n<p>Это письмо пишу с сайта. тест.</p>\n<p>&nbsp;</p>', '2011-09-20 13:01:25'),
(9, 'ask', 3, '<p>Абра-швабра-кадабра</p>', '2011-09-20 13:18:46');

-- --------------------------------------------------------

--
-- Table structure for table `itsnsk_news`
--

CREATE TABLE `itsnsk_news` (
  `id` smallint(6) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Table structure for table `itsnsk_page`
--

CREATE TABLE `itsnsk_page` (
  `id` smallint(6) NOT NULL,
  `content` longtext NOT NULL,
  `menu_id` smallint(6) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `itsnsk_page`
--

INSERT INTO `itsnsk_page` (`id`, `content`, `menu_id`) VALUES
(1, '<p><img style=\\\"margin: 20px; margin-left: 0px; margin-top: 0px;\\\" border=\\\"0\\\" alt=\\\"\\\" align=\\\"left\\\" src=\\\"/images/content_image.png\\\" /></p>\r\n<p><strong>ООО &quot;ИТ Сервис&quot; занимается ИТ-аутсорсингом.</strong></p>\r\n<p style=\\\"text-align: justify;\\\"><strong>В каждой организации есть локальная сеть, которая как любая структура нуждается во внимании и отладке. К тому же ни один современный офис не может сегодня обходится без интернета.&nbsp; Поэтому руководители фирм в конце концов приходят к мысли, что у них в офисе необходим специалист, который возьмет на себя все возникающие ИТ-проблемы. &nbsp;В крупных организациях такими вопросами занимаются ИТ-отделы.&nbsp; А если у Вас нет в штате высококвалифицированного системного администратора, то приходящий вполне может взять на себя эти функции.&nbsp;</strong><strong>Как показал многолетний опыт нашей фирмы, аутсорсинг ИТ-услуг - это выгодная и реально работающая услуга, которая способна полноценно удовлетворить всем требованиям современного бизнеса.</strong></p>\r\n<p style=\\\"text-align: justify;\\\"><strong>ООО &quot;ИТ Сервис&quot; отдает предпочтение договорным отношениям с партнерами. В этом случае за клиентом закрепляется &quot;свой&quot; системный администратор, который доступен в любое время. Он всегда в курсе всех насущных ИТ-проблем Вашего офиса. </strong></p>\r\n<p style=\\\"text-align: justify;\\\"><strong>Мы надеемся, что Вы по достоинству оцените <span style=\\\"text-decoration: underline;\\\"><a href=\\\"/?cat_id=3\\\">преимущества</a></span> ИТ-аутсорсинга, и сотрудничество с нашей фирмой принесет Вам &nbsp;успех.</strong></p>', 1),
(6, '<table border=\\\"0\\\" cellspacing=\\\"0\\\" cellpadding=\\\"0\\\" width=\\\"587\\\">\r\n<tbody>\r\n<tr>\r\n<td colspan=\\\"2\\\" width=\\\"587\\\" valign=\\\"top\\\">\r\n<p style=\\\"text-align: center;\\\"><strong>Описание услуг, &nbsp; предоставляемых ООО \\\"ИТ Сервис\\\" по договорам комплексного   обслуживания вычислительной техники</strong></p>\r\n<p style=\\\"text-align: center;\\\"><strong><br /></strong></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\\\"247\\\" valign=\\\"top\\\">\r\n<p><strong><br /></strong></p>\r\n</td>\r\n<td width=\\\"340\\\" valign=\\\"top\\\">\r\n<p><strong><br /></strong></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\\\"247\\\" valign=\\\"top\\\">\r\n<p><strong>компьютеры</strong></p>\r\n</td>\r\n<td width=\\\"340\\\" valign=\\\"top\\\">\r\n<p>Обеспечение   стабильной работы аппаратно-программного комплекса, включающего в себя   компьютер с обычным набором офисных программ.</p>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\\\"247\\\" valign=\\\"top\\\">\r\n<p><strong>Ноутбуки</strong></p>\r\n</td>\r\n<td width=\\\"340\\\" valign=\\\"top\\\">\r\n<p>Ноутбук   по сути является тем же компьютером, но из-за своей мобильности требует   несколько большего внимания, чем обычный компьютер.</p>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\\\"247\\\" valign=\\\"top\\\">\r\n<p><strong>Серверы</strong></p>\r\n</td>\r\n<td width=\\\"340\\\" valign=\\\"top\\\">\r\n<p>Обслуживание   windows-сервера. В связи со специфическими задачами, которые выполняет   сервер, его обслуживание стоит несколько дороже.</p>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\\\"247\\\" valign=\\\"top\\\">\r\n<p><strong>Наличие   сети</strong></p>\r\n</td>\r\n<td width=\\\"340\\\" valign=\\\"top\\\">\r\n<p>Текущее   обслуживание сетевой инфраструктуры офиса (провода, розетки, коммутаторы,   маршрутизаторы и т.д.), устранение неполадок, настройка компьютеров для   совместной работы в сети (количество сетей обычно равняется количеству   офисов).</p>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\\\"247\\\" valign=\\\"top\\\">\r\n<p><strong>Выход   в интернет (безопасность)</strong></p>\r\n</td>\r\n<td width=\\\"340\\\" valign=\\\"top\\\">\r\n<p>Обеспечение   стабильной работы интернет-каналов в части, зависимой от заказчика,   представление интереса заказчика в отношениях с провайдерами и другими   организациями, которые имеют к этому отношение. Обеспечение безопасности   информации и защиты от хакерских атак.</p>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\\\"247\\\" valign=\\\"top\\\">\r\n<p><strong>Эл   почта (почтовый сервер включая почтовый антивирус)</strong></p>\r\n</td>\r\n<td width=\\\"340\\\" valign=\\\"top\\\">\r\n<p>Настройка   и поддержка почтового сервера, обеспечение антивирусной защиты почтового   сервера и проходящей почты.</p>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\\\"247\\\" valign=\\\"top\\\">\r\n<p><strong>www   - сервер</strong></p>\r\n</td>\r\n<td width=\\\"340\\\" valign=\\\"top\\\">\r\n<p>Настройка   (совместно с разработчиками WWW-сайтов), и поддержка WWW-сервера. Сюда НЕ   входит создание и продвижение сайтов в поисковых машинах (это оплачивается   отдельно).</p>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\\\"247\\\" valign=\\\"top\\\">\r\n<p><strong>Антивирусная   защита (на компьютерах пользователей)</strong></p>\r\n</td>\r\n<td width=\\\"340\\\" valign=\\\"top\\\">\r\n<p>Обеспечение   оптимальной защиты компьютеров пользователей от компьютерных вирусов,   организация антивирусной защиты и регулярного обновления антивирусных   программ на компьютерах пользователей (равно количеству независимых сетей).</p>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\\\"247\\\" valign=\\\"top\\\">\r\n<p><strong>Организация   общих документов</strong></p>\r\n</td>\r\n<td width=\\\"340\\\" valign=\\\"top\\\">\r\n<p>Создание,   настройка и поддержание доступа к общим ресурсам сети и совместной работы с   общими документами и принтерами. Настройка разрешений для доступа к сетевым   ресурсам для пользователей в соответствии&nbsp;   концепцией безопасности организации.</p>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\\\"247\\\" valign=\\\"top\\\">\r\n<p><strong>Резервное   копирование документов</strong></p>\r\n</td>\r\n<td width=\\\"340\\\" valign=\\\"top\\\">\r\n<p>Разработка   стратегии резервного копирования. Организация, настройка и поддержание в   работоспособном состоянии системы резервного копирования документов и баз   данных на случай их утери.</p>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\\\"247\\\" valign=\\\"top\\\">\r\n<p><strong>IP   - телефония</strong></p>\r\n</td>\r\n<td width=\\\"340\\\" valign=\\\"top\\\">\r\n<p>Организация   оптимальной работы телефонной связи с использованием интернет-каналов,   представление интересов заказчика в отношениях с организациями - операторами   связи.</p>\r\n<p>&nbsp;</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td width=\\\"247\\\" valign=\\\"top\\\">\r\n<p><strong>Офисная   мини-АТС</strong></p>\r\n</td>\r\n<td width=\\\"340\\\" valign=\\\"top\\\">\r\n<p>Текущее   обслуживание и программирование офисных мини-АТС под нужды заказчика</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>', 7),
(2, '<table class=\\\"raschet\\\">\r\n<tbody>\r\n<tr>\r\n<td>\r\n<p>объект ответственности</p>\r\n</td>\r\n<td>кол-во</td>\r\n</tr>\r\n<tr>\r\n<td>Компьютеры\r\n<div id=\\\"computer_cost\\\" style=\\\"display: none;\\\">800</div>\r\n</td>\r\n<td><input id=\\\"computer_count\\\" type=\\\"text\\\" value=\\\"0\\\" /></td>\r\n</tr>\r\n<tr>\r\n<td>Ноутбуки\r\n<div id=\\\"laptop_cost\\\" style=\\\"display: none;\\\">1000</div>\r\n</td>\r\n<td><input id=\\\"laptop_count\\\" type=\\\"text\\\" value=\\\"0\\\" /></td>\r\n</tr>\r\n<tr>\r\n<td>Серверы\r\n<div id=\\\"server_cost\\\" style=\\\"display: none;\\\">1700</div>\r\n</td>\r\n<td><input id=\\\"server_count\\\" type=\\\"text\\\" value=\\\"0\\\" /></td>\r\n</tr>\r\n<tr>\r\n<td colspan=\\\"2\\\"><input onclick=\\\"recount_sum();\\\" type=\\\"button\\\" value=\\\"Подсчитать\\\" /></td>\r\n</tr>\r\n<tr>\r\n<td><strong>Итого: </strong></td>\r\n<td id=\\\"total_sum\\\">0</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p><br /> <br /> <br /></p>', 6),
(3, '<p><strong>630033, г. Новосибирск, ул. Обогатительная, 6 тел: 263-12-43</strong></p>\r\n<div id=\\\"YMapsID\\\">[Тут отображается Яндекс.Карта]</div>', 9),
(5, '', 2),
(7, '<p>&nbsp;</p>\r\n<ul>\r\n<li>отпадает необходимость иметь штатную единицу ИТ-специалиста и, как следствие, не нужно организовывать дополнительное рабочее место;</li>\r\n</ul>\r\n<ul>\r\n<li>реальная экономия (нет необходимости уплаты налогов с фонда оплаты труда);</li>\r\n</ul>\r\n<ul>\r\n<li>опыт сотрудника ИТ-аутсорсера несравнимо больше, нежели опыт офисного сисадмина, т.к. способен быстро принимать решения и выполнять задачи;</li>\r\n</ul>\r\n<ul>\r\n<li>при заключении договора &nbsp;появляются дополнительные гарантии качества выполняемых работ;</li>\r\n</ul>\r\n<ul>\r\n<li>работа с любым оборудованием и программным обеспечением;</li>\r\n</ul>\r\n<ul>\r\n<li>постоянная доступность ИТ-специалиста;</li>\r\n</ul>\r\n<ul>\r\n<li>решение большого количества возникающих проблем посредством удаленного доступа.</li>\r\n</ul>', 3),
(8, '<form id=\\\"send_message\\\" action=\\\"send.php\\\" method=\\\"post\\\">\r\n<p><strong><br /></strong></p>\r\n<table style=\\\"font-size: 13px;\\\" border=\\\"0\\\" cellspacing=\\\"0\\\" cellpadding=\\\"4\\\">\r\n<tbody>\r\n<tr>\r\n<td>\r\n<p>Ф.И.О.:</p>\r\n</td>\r\n<td><input name=\\\"name\\\" size=\\\"30\\\" /></td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p>Компания:</p>\r\n</td>\r\n<td><input name=\\\"company\\\" size=\\\"30\\\" /></td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p>Должность:</p>\r\n</td>\r\n<td><input name=\\\"status\\\" size=\\\"30\\\" /></td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p>Город:</p>\r\n</td>\r\n<td><input name=\\\"city\\\" size=\\\"30\\\" /></td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p>Телефон:</p>\r\n</td>\r\n<td><input name=\\\"phone\\\" size=\\\"30\\\" /></td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p>Факс:</p>\r\n</td>\r\n<td><input name=\\\"fax\\\" size=\\\"30\\\" /></td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p>Ваш E-mail:</p>\r\n</td>\r\n<td><input name=\\\"email\\\" size=\\\"30\\\" /></td>\r\n</tr>\r\n<tr>\r\n<td><img title=\\\"проверочный код\\\" src=\\\"/admin/captcha.php\\\" alt=\\\"проверочный код\\\" width=\\\"160\\\" height=\\\"60\\\" /></td>\r\n<td><input name=\\\"captcha_word\\\" size=\\\"30\\\" /></td>\r\n</tr>\r\n<tr>\r\n<td colspan=\\\"2\\\" align=\\\"center\\\">\r\n<p>Текст сообщения:</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td colspan=\\\"2\\\"><textarea cols=\\\"57\\\" rows=\\\"5\\\" name=\\\"message\\\"></textarea></td>\r\n</tr>\r\n<tr>\r\n<td colspan=\\\"2\\\"><input class=\\\"btn\\\" type=\\\"submit\\\" value=\\\"Отправить\\\" />&nbsp;<input class=\\\"btn\\\" type=\\\"reset\\\" value=\\\"Очистить\\\" /></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</form>\r\n<p><br /> <br /></p>', 5),
(9, '<p>Спасибо за ваше сообщение. Постараемся ответить в ближайшее время!</p>', 12);

-- --------------------------------------------------------

--
-- Table structure for table `itsnsk_rewrite_301`
--

CREATE TABLE `itsnsk_rewrite_301` (
  `id` int(11) NOT NULL,
  `template_url` varchar(255) NOT NULL,
  `serialized_template_url` text NOT NULL,
  `rewrite_url` varchar(255) NOT NULL,
  `date_last_requested` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Table structure for table `itsnsk_search`
--

CREATE TABLE `itsnsk_search` (
  `id` smallint(6) NOT NULL,
  `query_data` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `itsnsk_admins`
--
ALTER TABLE `itsnsk_admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itsnsk_clients`
--
ALTER TABLE `itsnsk_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itsnsk_gallery`
--
ALTER TABLE `itsnsk_gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itsnsk_images`
--
ALTER TABLE `itsnsk_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itsnsk_installed_modules`
--
ALTER TABLE `itsnsk_installed_modules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itsnsk_menu`
--
ALTER TABLE `itsnsk_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itsnsk_messages`
--
ALTER TABLE `itsnsk_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itsnsk_news`
--
ALTER TABLE `itsnsk_news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itsnsk_page`
--
ALTER TABLE `itsnsk_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itsnsk_rewrite_301`
--
ALTER TABLE `itsnsk_rewrite_301`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itsnsk_search`
--
ALTER TABLE `itsnsk_search`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `itsnsk_admins`
--
ALTER TABLE `itsnsk_admins`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `itsnsk_clients`
--
ALTER TABLE `itsnsk_clients`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `itsnsk_gallery`
--
ALTER TABLE `itsnsk_gallery`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `itsnsk_images`
--
ALTER TABLE `itsnsk_images`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `itsnsk_installed_modules`
--
ALTER TABLE `itsnsk_installed_modules`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `itsnsk_menu`
--
ALTER TABLE `itsnsk_menu`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `itsnsk_messages`
--
ALTER TABLE `itsnsk_messages`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `itsnsk_news`
--
ALTER TABLE `itsnsk_news`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `itsnsk_page`
--
ALTER TABLE `itsnsk_page`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `itsnsk_rewrite_301`
--
ALTER TABLE `itsnsk_rewrite_301`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `itsnsk_search`
--
ALTER TABLE `itsnsk_search`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
